// Grid-Based Game Assignment
// Samein Dorazahi
// 09/02/21
//
// Extra for Experts:
// - describe what you did to take this project "above and beyond"

let state = "not moving";
// used for both hardcoded and generated grids to count which grid you are currently on
let gridNumber = 0;
// hardcoded grids, must uncomment specific code for it to work
let holdingGrid = [[[0,1,0],[0,0,0],[0,1,0]], [[0,0,1],[1,0,0],[0,0,1]], [[0,1,1],[1,0,0],[0,1,1]]];
let grid = [];
let gridToWin = [];
let rows, cols, cellWidth, cellHeight, rectX, rectY, rectXC, rectYC;

function setup() {
  createCanvas(windowWidth, windowHeight);
  rows = floor(gridNumber/3) + 3;
  cols = floor(gridNumber/3) + 3;
  // grid = createRandomGrid(rows, cols);
  //replace generated grid with hardcoded grid
  grid = holdingGrid[gridNumber];
  gridToWin = createWinningGrid(rows, cols);
  cellWidth = width / 2 / cols;
  cellHeight = height / 2 / rows;
  rectX = width / 4; 
  rectY = height / 4;
}

function draw() {
  background("white");
  fill("black");
  textSize(37);
  text("Score: " + gridNumber, windowWidth / (windowWidth/30), windowHeight / (windowHeight/50));
  text("Level: " + (rows - 2), windowWidth / (windowWidth/30), windowHeight / (windowHeight/100));
  if (state === "moving") {
    moveGrid();
  }
  else if (state === "not moving") {
    displayGrid();
  }
}

function mousePressed() {
  let mouseXx = mouseX - width / 4;
  let mouseYy = mouseY - height / 4;
  let x = Math.floor(mouseXx / cellWidth);
  let y = Math.floor(mouseYy / cellHeight);
  toggleCell(x, y);   //self
  toggleCell(x, y + 1);
  toggleCell(x + 1, y);
  toggleCell(x, y - 1);
  toggleCell(x - 1, y);
  // variables that must be activated only once
  if (state === "not moving") {
    rectXC = rectX;
    rectYC = rectY;
    gridToWin = createWinningGrid(rows, cols);
  }
}

function moveGrid() {
  // creation and movement of grid looking rectangles
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      if (grid[y][x] === 0) {
        fill("white");
        rect(rectX + x * cellWidth + width, rectY + y * cellHeight, cellWidth, cellHeight);
      }
      else if (grid[y][x] === 1) {
        fill("black");
        rect(rectX + x * cellWidth + width, rectY + y * cellHeight, cellWidth, cellHeight);
      }
      fill("black");
      rect(rectX + x * cellWidth, rectY + y * cellHeight, cellWidth, cellHeight);
    }
  }
  // moves grid
  if (frameCount % 1 === 0) {
    rectX -= 6;
  }
  //checks if grid is now in position
  if (rectX < rectXC - width) {
    rectX = rectXC;
    rectY = rectYC;
    state = "not moving";
  }
}

function displayGrid() {
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      if (grid[y][x] === 0) {
        fill("white");
      }
      else {
        fill("black");
      }
      rect(x * cellWidth + width / 4, y * cellHeight + height / 4, cellWidth, cellHeight);
      if (JSON.stringify(grid) === JSON.stringify(gridToWin)) {
        state = "moving";
        gridNumber += 1;
        rows = floor(gridNumber/3) + 3;
        cols = floor(gridNumber/3) + 3;
        cellWidth = width / 2 / cols;
        cellHeight = height / 2 / rows;
        gridToWin = createWinningGrid(rows, cols);
        // grid = createRandomGrid(rows, cols);
        // uncomment and comment the ones above and below to experience hard coded grid
        grid = holdingGrid[gridNumber];
      }
    }      
  } 
}

function toggleCell(x, y) {
  //check that the coordinates are in the array
  if (x >= 0 && x < cols && y >= 0 && y < rows) {
    if (grid[y][x] === 1) {
      grid[y][x] = 0;
    }
    else if (grid[y][x] === 0) {
      grid[y][x] = 1;
    }
  }
}

// generates new grids upon winning
function createRandomGrid(cols, rows) {
  let emptyGrid = [];
  for (let y = 0; y<rows; y++) {
    emptyGrid.push([]);
    for (let x=0; x<cols; x++) {
      emptyGrid[y].push(round(random(0, 1)));
    }
  }
  return emptyGrid;
}

// generates the grid you must make
function createWinningGrid(cols, rows) {
  let emptyGrid = [];
  for (let y = 0; y<rows; y++) {
    emptyGrid.push([]);
    for (let x=0; x<cols; x++) {
      emptyGrid[y].push(1);
    }
  }
  return emptyGrid;
}